APM 3-SECOND CAMPUS SPLASH — UPDATED WEBSITE

1. Save a backup of your existing index.html and Firestore settings.
2. Upload this package's index.html to the root of your existing GitHub repository.
3. Keep your original market-logo.png, founder1.jpg, founder2.jpg, tng.png, sw.js and manifest.json.
4. The splash art is EMBEDDED inside index.html: you do not have to upload apm-splash.webp separately.
   The extra apm-splash.webp is an optional reusable image, not required by the page.
5. Hard-refresh your site (Ctrl+Shift+R) or clear your old service worker cache if needed.
6. Test in a phone browser: splash shows approx 3 seconds, then disappears automatically (or tap Skip).
7. Add Club should open for a signed-in, founder-approved account. Firestore rules must allow that account to create records in the clubs collection; frontend changes cannot override security rules.

This package changes the splash, hides the redundant old Welcome modal, and restores the missing Add Club open/close functions. It does not modify your Firebase project, Firestore rules, or existing data.
