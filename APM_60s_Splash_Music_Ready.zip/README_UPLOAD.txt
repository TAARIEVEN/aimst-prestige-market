APM SPLASH SCREEN WITH 60-SECOND MUSIC

1. Rename/use the included index.html (already correctly named).
2. Upload index.html to your APM GitHub Pages repository root.
3. Also upload YOUR OWN audio file, named exactly splashscreenbgm.mp3, to that same folder.
   It was visible in your screenshot, but the actual MP3 was not attached, so it is not included here.
4. Keep market-logo.png, founder1.jpg, founder2.jpg, tng.png, sw.js, and manifest.json from your existing repository.
5. Splash timing: 60 seconds, followed by a short fade. It can be skipped any time.
6. Browsers often block autoplay. Visitors can tap the top-left music button to play/pause.
7. Refresh your GitHub Pages site. If the old splash persists, hard-refresh and clear service-worker cache.

IMPORTANT: For regular users a 60-second splash may be too long; the Skip button remains available.
This update changes only the splash screen music and duration, not your Firebase security rules.
